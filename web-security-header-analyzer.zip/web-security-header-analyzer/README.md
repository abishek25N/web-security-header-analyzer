# 🛡️ Web Security Header Analyzer

A Streamlit app that passively checks a website's HTTP response headers and reports rule-based findings, with downloadable HTML and JSON reports.

## Headers checked
- Content-Security-Policy
- Strict-Transport-Security
- X-Content-Type-Options
- X-Frame-Options
- Referrer-Policy

## Features
- Score out of 100 with per-header severity and recommendations
- SSRF guards: blocks localhost, private/loopback/non-public IPs, and embedded credentials
- Manual redirect handling (max 5 hops), with each hop re-validated
- Does not download response bodies
- Export results as HTML or JSON

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Project structure
| File | Purpose |
|---|---|
| `app.py` | Streamlit UI |
| `analyzer.py` | URL validation, fetching, header evaluation |
| `reports.py` | HTML and JSON report builders |

## Disclaimer
Only test websites you own or are explicitly authorized to assess. This tool checks response headers only and is not a complete security audit.
