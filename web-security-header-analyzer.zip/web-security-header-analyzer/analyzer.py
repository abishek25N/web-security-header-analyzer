from __future__ import annotations
from datetime import datetime, timezone
from urllib.parse import urlparse, urlunparse
import ipaddress
import socket
import requests
import urllib3.util.connection as _urllib3_connection

TIMEOUT_SECONDS = 10
MAX_REDIRECTS = 5
MAX_BODY_BYTES = 1_000_000
USER_AGENT = "WebSecurityHeaderAnalyzer/1.0 (educational passive header checker)"

class _BlockedAddressError(OSError):
    """Raised when a connection would go to a non-public address."""

_original_create_connection = _urllib3_connection.create_connection

def _safe_create_connection(address, *args, **kwargs):
    """Resolve once, validate every address, then connect to the validated IP.

    This closes the DNS-rebinding gap: the IP that is checked is the same IP
    that is connected to. TLS SNI and certificate checks still use the hostname.
    """
    host, port = address
    host = host.strip("[]")
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise _BlockedAddressError(f"Could not resolve hostname: {exc}") from exc
    ips = []
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            raise _BlockedAddressError("Unrecognized address; connection blocked.")
        if not ip.is_global:
            raise _BlockedAddressError("Private, local, loopback, and non-public network targets are blocked.")
        ips.append(str(ip))
    if not ips:
        raise _BlockedAddressError("The hostname did not resolve to an IP address.")
    return _original_create_connection((ips[0], port), *args, **kwargs)

_urllib3_connection.create_connection = _safe_create_connection

class AnalyzerError(Exception):
    """Expected validation or network error shown to the user."""

def normalize_url(value: str) -> str:
    value = value.strip()
    if not value:
        raise AnalyzerError("Please enter a website URL.")
    if "://" not in value:
        value = "https://" + value
    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https"):
        raise AnalyzerError("Only HTTP and HTTPS URLs are supported.")
    if not parsed.hostname:
        raise AnalyzerError("The URL must contain a valid hostname.")
    if parsed.username or parsed.password:
        raise AnalyzerError("URLs containing embedded usernames or passwords are not allowed.")
    if parsed.port and not (1 <= parsed.port <= 65535):
        raise AnalyzerError("Invalid port.")
    if parsed.hostname.lower() == "localhost":
        raise AnalyzerError("Localhost targets are blocked.")
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path or "/", parsed.params, parsed.query, ""))

def _assert_public_host(hostname: str) -> None:
    try:
        literal_ip = ipaddress.ip_address(hostname)
        addresses = [literal_ip]
    except ValueError:
        try:
            answers = socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM)
            addresses = [ipaddress.ip_address(item[4][0]) for item in answers]
        except socket.gaierror as exc:
            raise AnalyzerError(f"Could not resolve hostname: {exc}") from exc
    if not addresses:
        raise AnalyzerError("The hostname did not resolve to an IP address.")
    for address in addresses:
        if not address.is_global:
            raise AnalyzerError("Private, local, loopback, and non-public network targets are blocked.")

def fetch_headers(url: str) -> tuple[requests.Response, str]:
    current = normalize_url(url)
    session = requests.Session()
    session.trust_env = False  # ignore proxy env vars so the IP guard cannot be bypassed
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "*/*"})
    for hop in range(MAX_REDIRECTS + 1):
        parsed = urlparse(current)
        _assert_public_host(parsed.hostname)
        try:
            response = session.get(
                current, timeout=TIMEOUT_SECONDS, allow_redirects=False,
                stream=True, verify=True
            )
        except requests.RequestException as exc:
            raise AnalyzerError(f"Unable to connect securely: {exc}") from exc
        if response.is_redirect or response.is_permanent_redirect:
            location = response.headers.get("Location")
            response.close()
            if not location:
                raise AnalyzerError("The server returned a redirect without a Location header.")
            if hop == MAX_REDIRECTS:
                raise AnalyzerError("Too many redirects.")
            from urllib.parse import urljoin
            current = normalize_url(urljoin(current, location))
            continue
        # Do not download the response body; close immediately after headers arrive.
        response.close()
        return response, current
    raise AnalyzerError("Redirect limit exceeded.")

def _evaluate(name: str, value: str | None, is_https: bool) -> dict:
    v = (value or "").strip()
    present = bool(v)
    status, severity, finding, recommendation = "Good", "Info", "Header is present.", "Keep this header aligned with the application's requirements."
    if name == "Content-Security-Policy":
        if not present:
            status, severity = "Missing", "High"
            finding = "No Content-Security-Policy response header was detected."
            recommendation = "Define a policy appropriate to the application. Start with a report-only policy, test it, then enforce it. Avoid broad wildcard sources and unsafe directives."
        else:
            weak = []
            if "'unsafe-inline'" in v.lower(): weak.append("unsafe-inline")
            if "'unsafe-eval'" in v.lower(): weak.append("unsafe-eval")
            if "*" in v: weak.append("wildcard source")
            if weak:
                status, severity = "Review", "Medium"
                finding = "Potentially permissive directive(s) detected: " + ", ".join(weak) + ". Context matters; verify whether these are necessary."
                recommendation = "Reduce broad sources and unsafe directives where possible. Prefer nonces or hashes for inline scripts and test changes before enforcement."
    elif name == "Strict-Transport-Security":
        if not present:
            if is_https:
                status, severity = "Missing", "Medium"
                finding = "HSTS was not detected on the HTTPS response."
                recommendation = "For HTTPS-only sites, consider max-age of at least 15552000 seconds. Add includeSubDomains only when every subdomain supports HTTPS."
            else:
                status, severity = "N/A", "Info"
                finding = "HSTS is meaningful only when delivered over HTTPS."
                recommendation = "Serve the site over HTTPS, then configure HSTS on HTTPS responses."
        else:
            import re
            match = re.search(r"max-age\s*=\s*(\d+)", v, re.I)
            if not match or int(match.group(1)) < 15552000:
                status, severity = "Review", "Medium"
                finding = "HSTS max-age is missing or shorter than the project's six-month review threshold."
                recommendation = "Consider max-age=15552000 or longer after confirming HTTPS works across the site."
    elif name == "X-Content-Type-Options":
        if not present:
            status, severity = "Missing", "Medium"
            finding = "The header was not detected."
            recommendation = "Set X-Content-Type-Options: nosniff."
        elif v.lower() != "nosniff":
            status, severity = "Review", "Low"
            finding = f"Expected 'nosniff'; received '{v}'."
            recommendation = "Use X-Content-Type-Options: nosniff."
    elif name == "X-Frame-Options":
        if not present:
            status, severity = "Missing", "Medium"
            finding = "The header was not detected."
            recommendation = "Use DENY or SAMEORIGIN when appropriate, or configure CSP frame-ancestors."
        elif v.upper() not in ("DENY", "SAMEORIGIN"):
            status, severity = "Review", "Low"
            finding = f"Value '{v}' is not one of the commonly recommended legacy values."
            recommendation = "Use DENY or SAMEORIGIN, or prefer a suitable CSP frame-ancestors policy."
    elif name == "Referrer-Policy":
        if not present:
            status, severity = "Missing", "Low"
            finding = "The header was not detected."
            recommendation = "Consider strict-origin-when-cross-origin or no-referrer, depending on application needs."
        elif v.lower() in ("unsafe-url", "no-referrer-when-downgrade"):
            status, severity = "Review", "Medium"
            finding = f"'{v}' may disclose more referrer information than necessary."
            recommendation = "Consider strict-origin-when-cross-origin or no-referrer."
    return {
        "header": name, "status": status, "value": v or "Not present",
        "severity": severity, "finding": finding, "recommendation": recommendation
    }

def analyze_url(url: str) -> dict:
    response, final_url = fetch_headers(url)
    raw = dict(response.headers)
    is_https = urlparse(final_url).scheme == "https"
    names = [
        "Content-Security-Policy", "Strict-Transport-Security",
        "X-Content-Type-Options", "X-Frame-Options", "Referrer-Policy"
    ]
    rows = [_evaluate(name, raw.get(name), is_https) for name in names]
    weights = {"Good": 20, "Review": 10, "Missing": 0, "N/A": 20}
    score = sum(weights[row["status"]] for row in rows)
    return {
        "target_url": normalize_url(url), "final_url": final_url,
        "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "status_code": response.status_code,
        "content_type": response.headers.get("Content-Type", "Not supplied"),
        "raw_headers": raw, "headers": rows, "score": score,
        "present_count": sum(1 for row in rows if row["status"] in ("Good", "Review")),
        "finding_count": sum(1 for row in rows if row["status"] in ("Missing", "Review")),
        "scope_note": "Passive response-header assessment only; not a complete security audit."
    }
