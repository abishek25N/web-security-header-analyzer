import html
import json

def build_json_report(result: dict) -> str:
    return json.dumps(result, indent=2, ensure_ascii=False)

def build_html_report(result: dict) -> str:
    rows = []
    for item in result["headers"]:
        rows.append(
            "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                html.escape(item["header"]), html.escape(item["status"]),
                html.escape(item["severity"]), html.escape(item["value"]),
                html.escape(item["recommendation"])
            )
        )
    return """<!doctype html><html><head><meta charset="utf-8"><title>Security Header Report</title>
<style>body{font-family:Arial,sans-serif;background:#0b1220;color:#e8eef8;padding:32px}
.card{background:#142238;padding:20px;border-radius:12px;margin-bottom:20px}
table{border-collapse:collapse;width:100%;background:#142238}th,td{padding:12px;border:1px solid #31445e;text-align:left}
th{background:#203650}small{color:#9fb0c7}</style></head><body>
<h1>Web Security Header Analyzer</h1><div class="card">
<h2>Assessment summary</h2><p><b>Target:</b> {target}</p><p><b>Final URL:</b> {final}</p>
<p><b>Checked:</b> {checked}</p><p><b>HTTP status:</b> {status}</p>
<p><b>Security score:</b> {score}/100</p><small>{note}</small></div>
<h2>Header findings</h2><table><thead><tr><th>Header</th><th>Status</th><th>Severity</th><th>Value</th><th>Recommendation</th></tr></thead>
<tbody>{rows}</tbody></table><p><small>Header presence alone does not guarantee a secure configuration. Review recommendations against application requirements.</small></p>
</body></html>""".format(
        target=html.escape(result["target_url"]), final=html.escape(result["final_url"]),
        checked=html.escape(result["checked_at"]), status=result["status_code"],
        score=result["score"], note=html.escape(result["scope_note"]), rows="".join(rows)
    )
