import streamlit as st
import pandas as pd
from analyzer import analyze_url, AnalyzerError
from reports import build_html_report, build_json_report

st.set_page_config(page_title="Web Security Header Analyzer", page_icon="🛡️", layout="wide")

st.markdown("""
<style>
.stApp {background: radial-gradient(circle at 10% 0%, #13243b 0, #09111f 42%, #070c16 100%); color:#e8eef8;}
.block-container {padding-top:2rem; max-width:1250px;}
[data-testid="stMetric"] {background:#111e30; border:1px solid #263b55; padding:16px; border-radius:14px;}
div[data-testid="stExpander"] {background:#101c2c; border:1px solid #263b55; border-radius:12px;}
.stButton>button {background:#16a6a0; color:white; border:0; border-radius:9px; font-weight:700;}
.stTextInput input {background:#101c2c; color:#e8eef8;}
.small-muted {color:#9fb0c7;}
.hero {padding:22px 24px; border:1px solid #29435f; border-radius:18px; background:linear-gradient(120deg,#10243a,#112d39);}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>🛡️ Web Security Header Analyzer</h1><p class="small-muted">Passive HTTP response-header assessment · Rule-based findings · Exportable reports</p></div>', unsafe_allow_html=True)
st.write("")
st.info("Only assess websites you own or are explicitly authorized to test. This tool checks response headers only; it is not a complete security audit.")

with st.sidebar:
    st.header("About")
    st.markdown("**Assessment scope**")
    st.markdown("- Content-Security-Policy\n- Strict-Transport-Security\n- X-Content-Type-Options\n- X-Frame-Options\n- Referrer-Policy")
    st.markdown("---")
    st.caption("Python · Requests · Streamlit · Pandas")
    st.caption("Requests are limited to public internet hosts. Local/private network targets are blocked.")

url = st.text_input("Website URL", placeholder="https://example.com")
run = st.button("Analyze security headers", type="primary", use_container_width=True)

if run:
    if not url.strip():
        st.warning("Enter a website URL to begin.")
    else:
        with st.spinner("Fetching response headers and evaluating configuration..."):
            try:
                result = analyze_url(url.strip())
                st.session_state["last_result"] = result
            except AnalyzerError as exc:
                st.error(str(exc))
            except Exception as exc:
                st.error(f"Unexpected error: {exc}")

result = st.session_state.get("last_result")
if result:
    st.markdown("## Assessment overview")
    a, b, c, d = st.columns(4)
    a.metric("Security score", f"{result['score']}/100")
    b.metric("Present headers", f"{result['present_count']}/5")
    c.metric("Findings", result["finding_count"])
    d.metric("HTTP status", result["status_code"])
    st.caption(f"Target: {result['final_url']} · Checked: {result['checked_at']}")

    st.markdown("### Header assessment")
    df = pd.DataFrame(result["headers"])
    st.dataframe(df[["header", "status", "value", "severity", "recommendation"]], use_container_width=True, hide_index=True)

    st.markdown("### Findings and recommendations")
    for item in result["headers"]:
        if item["status"] != "Good":
            with st.expander(f"{item['severity']} · {item['header']} — {item['status']}", expanded=True):
                st.write(item["finding"])
                st.markdown(f"**Recommendation:** {item['recommendation']}")

    st.markdown("### Response details")
    st.write(f"**Final URL:** {result['final_url']}")
    st.write(f"**Content type:** {result.get('content_type', 'Not supplied')}")
    with st.expander("View collected response headers"):
        st.json(result["raw_headers"])

    html_data = build_html_report(result)
    json_data = build_json_report(result)
    x, y = st.columns(2)
    x.download_button("⬇️ Download HTML report", html_data, file_name="security_header_report.html", mime="text/html", use_container_width=True)
    y.download_button("⬇️ Download JSON report", json_data, file_name="security_header_report.json", mime="application/json", use_container_width=True)
